"""
Tests for Mulberry Spirit Score System
"""
